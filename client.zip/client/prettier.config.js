// prettier.config.js
module.exports = {
    plugins: [require('prettier-plugin-tailwindcss')],
  }