const Blog = [
  {
    img: "/assets/images/blog/blog-1.png",
    title: "The Huge Power Danger of AI-Generated Code",
    date: "30-06-2023",
  },
  {
    img: "/assets/images/blog/blog-2.png",
    title: "There’s Finally a Way to Secure a Crucial Piece",
    date: "30-06-2023",
  },
  {
    img: "/assets/images/blog/blog-3.png",
    title: "How Google Docs Proved the Power of Less",
    date: "30-06-2023",
  },
  {
    img: "/assets/images/blog/blog-4.png",
    title: "Stack Overflow Will Charge AI Giants for Training Data",
    date: "30-06-2023",
  },
  {
    img: "/assets/images/blog/blog-5.png",
    title: "Chat GPT’s API Is Here. Let the AI Gold Rush Begin",
    date: "30-06-2023",
  },
  {
    img: "/assets/images/blog/blog-6.png",
    title: "GitHub Moves to Guard Open Source Supply Chain Attacks",
    date: "30-06-2023",
  },
];

export default Blog;
