const DashboardHome = () => <h1 className="text-3xl flex justify-center items-center mt-20">Welcome to Dashboard</h1>;
export default DashboardHome;