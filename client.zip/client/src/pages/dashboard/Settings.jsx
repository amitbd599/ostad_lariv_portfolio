const Settings = () => <h1 className="text-3xl">Settings Page</h1>;
export default Settings;